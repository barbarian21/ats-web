import os
from subprocess import *
import time
import Tkinter
import tkFileDialog
import ttk
from Tkinter import StringVar,IntVar
# Import smtplib for the actual sending function
import smtplib
# Import the email modules we'll need
from email.mime.text import MIMEText
# Open a plain text file for reading.  For this example, assume that
# the text file contains only ASCII characters.
# Create a text/plain message
path_memory_ex = os.path.exists(os.environ['HOME']+'/Documents/AutoBuild')
if not path_memory_ex:
    os.makedirs(os.environ['HOME']+'/Documents/AutoBuild')
path_memory = os.environ['HOME']+'/Documents/AutoBuild'
PWDPath = path_memory + '/PWD.txt'
Memory_path = path_memory + '/Memory.txt'
def initUI():
    global Lable_end
    global text
    global top
    global entry_target
    global listbox_target
    global Combobox_target
    global entry_atlasvers
    global entry_branch
    global default_tag
    global entry_tag
    global Combobox_tag
    global listbox_tag
    global entry_build
    global s_mail
    global file_repo
    global CheckVar_ccATS

    top = Tkinter.Tk()
    top.title("AutoBuildTool")
    text = StringVar()

    lable_1_1 = Tkinter.Label(top,text = " ")
    lable_1_1.grid(row = 0,column = 1,sticky=Tkinter.E)
    button = Tkinter.Button(top,text='logout',command = logout).grid(row = 0,column = 5)

    lable_target = Tkinter.Label(top,text = "target")
    lable_target.grid(row = 5,column = 1,sticky=Tkinter.E)
    default_target = StringVar()
    default_target.set('iPhoneQT_N104-')
    entry_target = Tkinter.Entry(top,width = 13,bg = "#FFC0CB",textvariable = default_target)
    entry_target.grid(row = 5,column = 3,sticky=Tkinter.E)
    listbox_target=[]
    Combobox_target = ttk.Combobox(top,width = 23,values=listbox_target)
    Combobox_target.grid(row = 5,column = 4)
    lable_aaa = Tkinter.Label(top,text = "                   ")
    lable_aaa.grid(row = 5,column = 5)

    lable_atlasvers = Tkinter.Label(top,text = "atlasvers")
    lable_atlasvers.grid(row = 10,column = 1,sticky=Tkinter.E)
    default_atlasvers = StringVar()
    default_atlasvers.set('1.12.0')
    entry_atlasvers = Tkinter.Entry(top,width = 25,bg = "#FFC0CB",textvariable = default_atlasvers)
    entry_atlasvers.grid(row = 10,column = 4,sticky=Tkinter.W)

    lable_branch = Tkinter.Label(top,text = "branch")
    lable_branch.grid(row = 20,column = 1,sticky=Tkinter.E)
    entry_branch = Tkinter.Entry(top,width = 25,bg = "#FFC0CB")
    entry_branch.grid(row = 20,column = 4,sticky=Tkinter.W)

    lable_tag = Tkinter.Label(top,text = "tag")
    lable_tag.grid(row = 30,column = 1,sticky=Tkinter.E)
    listbox_tag=[]
    Combobox_tag = ttk.Combobox(top,width = 23)
    Combobox_tag.grid(row = 30,column = 4,sticky=Tkinter.W)
    button_tag = Tkinter.Button(top,text='choose',command =choose_tag)
    button_tag.grid(row = 30,column = 5)

    lable_build = Tkinter.Label(top,text = "build")
    lable_build.grid(row = 40,column = 1,sticky=Tkinter.E)
    default_build = StringVar()
    default_build.set('P2')
    entry_build = Tkinter.Entry(top,width = 25,bg = "#FFC0CB",textvariable = default_build)
    entry_build.grid(row = 40,column = 4,sticky=Tkinter.W)

    CheckVar_ccATS = IntVar()
    lable_CCATS = Tkinter.Label(top,text = "ccATS")
    lable_CCATS.grid(row = 50,column = 1,sticky=Tkinter.E)
    Checkbutton_password = Tkinter.Checkbutton(top,variable = CheckVar_ccATS,onvalue = 1, offvalue = 0)
    Checkbutton_password.grid(row = 50,column = 4,sticky=Tkinter.W)

    button_send = Tkinter.Button(top,text='send',command =send)
    button_send.grid(row = 70,column = 4,sticky=Tkinter.W)
    Lable_end = Tkinter.Label(textvariable = text)
    Lable_end.grid(row = 80,column = 4,sticky=Tkinter.W)
    array_memory = []
    if (os.path.exists(Memory_path)):
        file_memory = open(Memory_path)
        file_object = open(Memory_path,'rU')
        try:
            for line in file_object:
                array_memory=array_memory+[line.strip()]
        finally:
            file_object.close()
        if(len(array_memory)>1):
            default_atlasvers.set(array_memory[0])
            default_build.set(array_memory[1])
            file_repo = ''
            if(len(array_memory)>2):
                file_repo = array_memory[2]   
            if(os.path.exists(file_repo)):
                dic_log = git_log(file_repo)
                listbox_tag = []
                for item in dic_log:
                    s_insert = item['id'][0:7]+'   '+item['date']
                    listbox_tag.insert(len(listbox_tag),s_insert)
                Combobox_tag["values"] = listbox_tag
                folder_target = file_repo
                if (os.path.exists(folder_target)):
                    files = os.listdir(folder_target)
                    for file in files:
                        m = os.path.join(folder_target,file)
                        if (os.path.isdir(m)):
                            h = os.path.split(m)
                            print h[1]
                            listbox_target.append(h[1])
                Combobox_target["values"] = listbox_target
    top.mainloop()


def input_pwd():
    global entry_username
    global entry_password
    global PWDUI
    PWDUI = Tkinter.Tk()
    PWDUI.title("Please Input Username and Password")
    lable_username = Tkinter.Label(PWDUI,text = "UserName")
    lable_username.grid(row = 50,column = 1)
    entry_username = Tkinter.Entry(PWDUI,width = 30,bg = "Green")
    entry_username.grid(row = 50,column = 3,sticky=Tkinter.W)

    lable_password = Tkinter.Label(PWDUI,text = "PassWord")
    lable_password.grid(row = 60,column = 1)
    entry_password = Tkinter.Entry(PWDUI,width = 30,bg = "Green",show = '*')
    entry_password.grid(row = 60,column = 3,sticky=Tkinter.W)
    button_ok = Tkinter.Button(PWDUI,text = "OK",command = PWD_OK)
    button_ok.grid(row = 80,column = 3,sticky=Tkinter.W)
    PWDUI.mainloop()
def send():
    login()
    s_target_now = Combobox_target.get()
    s_tag_now = Combobox_tag.get()[0:7]
    text.set("Begin send...")
    top.update()
    if(s_target_now == ""):
        text.set("Send fail,Please select a target")
        return
    if(s_tag_now == ""):
        text.set("Send fail,Please select a tag")
        # return
    content = '''
    TARGET = %s
    ATLASVERS = %s
    BRANCH = %s
    TAG = %s
    EMAIL = %s@pegatroncorp.com
    BUILD = %s
    ''' % (entry_target.get()+s_target_now,entry_atlasvers.get(),entry_branch.get(),s_tag_now,USERNAME,entry_build.get())
    msg = MIMEText(content)
    msg['Subject'] = 'pegatron build request'
    msg['From'] = "%s@pegatroncorp.com" % USERNAME
    msg['To'] = "qt-buildrequest@buildcave.hwte.apple.com"
    # msg['To'] = "Guitar_Li@pegatroncorp.com"
    print("CheckVar_ccATS")
    print(CheckVar_ccATS.get())
    if(CheckVar_ccATS.get() == 1):
        msg['Cc'] ="%s@pegatroncorp.com,Bison_ATS@pegatroncorp.com" % USERNAME
    else:
        msg['Cc'] = "%s@pegatroncorp.com" % USERNAME
    try:
        s_mail = smtplib.SMTP('mail.sh.pegatroncorp.com')
    except:
        text.set("Send fail, SMTP error")
    else:
        try:
            s_mail.login(USERNAME, PASSWORD)
        except:
            text.set("Send fail, Username or Password error")
            if(os.path.exists(PWDPath)):
                os.remove(PWDPath)
        else:
            try:
                s_mail.sendmail(msg['From'],msg['To'].split(',')+msg['Cc'].split(','),msg.as_string())
            except:
                text.set("Send fail")
            else:
                try:
                    s_mail.quit()
                except:
                    text.set("Send Success,but quit fail")
                else:
                    text.set("Send success")
    f = open(Memory_path, 'w')
    f.write(entry_atlasvers.get())
    f.write('\n')
    f.write(entry_build.get())
    f.write('\n')
    f.write(file_repo)
    f.close()
def PWD_OK():
    if(os.path.exists(PWDPath)):
        os.remove(PWDPath)
    f = open(PWDPath, 'w')
    f.write(entry_username.get())
    f.write('\n')
    f.write(entry_password.get())
    f.close()
    PWDUI.destroy()
def login():
    global USERNAME
    global PASSWORD
    if(os.path.exists(PWDPath)):
        file_PWD = open(PWDPath)
        array_PWD = []
        file_object = open(PWDPath,'rU')
        try: 
            for line in file_object:
                array_PWD=array_PWD+[line.strip()]
        finally:
            file_object.close()
        if(len(array_PWD)>1):
            USERNAME = array_PWD[0]
            PASSWORD = array_PWD[1]
        else:
            os.remove(PWDPath)
    else:
        input_pwd()
def logout():
    if(os.path.exists(PWDPath)):
        os.remove(PWDPath)
        text.set("Logout success")
    else:
        text.set("No user login,No need to logout")
def git_log(repo):
    git_commit_fields = ['id', 'author_name', 'author_email', 'date', 'message']
    git_log_format = ['%H', '%an', '%ae', '%ad', '%s']
    git_log_format = '%x1f'.join(git_log_format) + '%x1e'
    p = Popen('cd %s && git log --format="%s"' % (repo,git_log_format), shell=True, stdout=PIPE)
    (log, _) = p.communicate()
    log = log.strip('\n\x1e').split("\x1e")
    log = [row.strip().split("\x1f") for row in log]
    log = [dict(zip(git_commit_fields, row)) for row in log]
    return log
def choose_tag():
    global file_repo
    file_repo = tkFileDialog.askdirectory(title='Open file')
    print(file_repo)
    dic_log = git_log(file_repo)
    listbox_tag = []
    for item in dic_log:
        s_insert = item['id'][0:7]+'   '+item['date']
        print('tag',item['id'][0:7],'time:',item['date'])
        listbox_tag.insert(len(listbox_tag),s_insert)
    Combobox_tag["values"] = listbox_tag
    folder_target = file_repo
    if (os.path.exists(folder_target)):
        files = os.listdir(folder_target)
        for file in files:
            m = os.path.join(folder_target,file)
            if (os.path.isdir(m)):
                h = os.path.split(m)
                print h[1]
                listbox_target.append(h[1])
    Combobox_target["values"] = listbox_target
    f = open(Memory_path, 'w')
    f.write(entry_atlasvers.get())
    f.write('\n')
    f.write(entry_build.get())
    f.write('\n')
    f.write(file_repo)
    f.close()
initUI()